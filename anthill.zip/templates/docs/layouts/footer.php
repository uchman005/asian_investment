</div>
<!--//page-wrapper-->
<footer id="footer" class="footer text-center">
    <div class="container">
        <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <span class="copyright">Designed By <i class="fas fa-heart"></i> by <a href="https://golojan.net/" target="_blank">De-Golojan</a> for PHP developers</span>

    </div>
    <!--//container-->
</footer>
<!--//footer-->
<!-- Main Javascript -->
<script type="text/javascript" src="templates/docs/assets/plugins/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="templates/docs/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/docs/assets/plugins/prism/prism.js"></script>
<script type="text/javascript" src="templates/docs/assets/plugins/jquery-scrollTo/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="templates/docs/assets/plugins/stickyfill/dist/stickyfill.min.js"></script>
<script type="text/javascript" src="templates/docs/assets/js/main.js"></script>
</body>
</html>